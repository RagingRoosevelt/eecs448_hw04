hw04
====

EECS 448 - HW04

Files needed in order to run:
* __init__.py
* cController.py
* cModel.py
* cView.py
* hw04.py

To run, place all files in the same directory, then execute the command "python hw04.py" from the command prompt or command line.